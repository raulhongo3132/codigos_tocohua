#include <iostream>
#include <math.h>
#include <locale.h>
#include <stdlib.h>
#include <string>

using namespace std;

int main(){
    float x1, y1, x2, y2, x3, y3, x4, y4, a, b, c, d;
    char N[] = "";
    string g;
    setlocale(LC_ALL, "");
    cout << endl << endl << "\t\tPrograma que calcula el modelo de interpolaci�n c�bica e interpola diferentes valores.";
    cout << endl << endl;

    do {
        cout << endl << "\t\tIngrese el valor de x1: ";
        cin >> g;
        x1 = atof(g.c_str());
        cout << endl << "\t\tIngrese el valor de y1: ";
        cin >> g;
        y1 = atof(g.c_str());
        cout << endl << "\t\tIngrese el valor de x2: ";
        cin >> g;
        x2 = atof(g.c_str());
        cout << endl << "\t\tIngrese el valor de y2: ";
        cin >> g;
        y2 = atof(g.c_str());
        cout << endl << "\t\tIngrese el valor de x3: ";
        cin >> g;
        x3 = atof(g.c_str());
        cout << endl << "\t\tIngrese el valor de y3: ";
        cin >> g;
        y3 = atof(g.c_str());
        cout << endl << "\t\tIngrese el valor de x4: ";
        cin >> g;
        x4 = atof(g.c_str());
        cout << endl << "\t\tIngrese el valor de y4: ";
        cin >> g;
        y4 = atof(g.c_str());

        if (x1 == x2 || x2 == x3 || x3 == x4 || x1 == x3 || x1 == x4 || x2 == x4) {
            cout << endl << "\t\tNo es posible encontrar el modelo de interpolaci�n c�bica.";
            continue;
        }
        if (y1 == y2 && y2 == y3 && y3 == y4) {
            cout << endl << "\t\tEl modelo de interpolaci�n c�bica es constante.";
            cout << endl << "\t\ty = " << y1;
            return 0;
        }
    } while (x1 == x2 || x2 == x3 || x3 == x4 || x1 == x3 || x1 == x4 || x2 == x4);

    // Calcular los coeficientes de la ecuaci�n c�bica
    // Matriz aumentada
    float matriz[4][5] = {
        {x1 * x1 * x1, x1 * x1, x1, 1, y1},
        {x2 * x2 * x2, x2 * x2, x2, 1, y2},
        {x3 * x3 * x3, x3 * x3, x3, 1, y3},
        {x4 * x4 * x4, x4 * x4, x4, 1, y4}
    };

    // Aplicar el m�todo de Gauss-Jordan
    for (int i = 0; i < 4; i++) {
        float coef = matriz[i][i];
        for (int j = 0; j < 5; j++) {
            matriz[i][j] /= coef;
        }

        for (int k = 0; k < 4; k++) {
            if (k != i) {
                coef = matriz[k][i];
                for (int j = 0; j < 5; j++) {
                    matriz[k][j] -= coef * matriz[i][j];
                }
            }
        }
    }

    a = matriz[0][4];
    b = matriz[1][4];
    c = matriz[2][4];
    d = matriz[3][4];

    cout << endl << "\t\tEl modelo de interpolaci�n c�bica es: y = " 
         << a << "x^3 + " << b << "x^2 + " << c << "x + " << d << endl;

    int n;
    do {
        cout << endl << endl << "\t\tD�game cu�ntos datos desea interpolar: ";
        cin >> N;
        n = atoi(N);
    } while (n <= 1);

    float X[n + 4], Y[n + 4]; // Cambi� el tama�o a n + 4 para incluir los extremos
    X[0] = x1; Y[0] = y1;
    X[1] = x2; Y[1] = y2;
    X[2] = x3; Y[2] = y3;
    X[n + 3] = x4; Y[n + 3] = y4; // Aseguramos que los extremos est�n incluidos

    int j;
    float x;
    bool vf;
    for (int i = 3; i < n + 3; i++) {
        do {
            vf = true;
            cout << endl << "\t\tIngrese el valor de x" << i - 2 << " a interpolar: ";
            cin >> g;
            x = atof(g.c_str());
            if (x < X[0] || x > X[n + 3]) {
                cout << endl << "\t\tEste valor no se puede interpolar, no se encuentra entre " << X[0] << " y " << X[n + 3] << ". Vuelve a intentarlo.";
            } else {
                for (j = 0; j < i; j++) {
                    if (x == X[j]) {
                        cout << endl << "\t\tEl valor que ingresaste ya existe. Forma parte de los datos.";
                        vf = false;
                    }
                }
            }
            if (vf) X[i] = x;
        } while ((x < X[0] || x > X[n + 3]) || !vf);
    }

    cout << endl << "\t\tLos valores de la tabla sin ordenar son:" << endl;
    cout << endl << "\t\tx\t|\ty" << endl << "\t\t===================";
    for (int i = 0; i < n + 4; i++) {
        Y[i] = a * pow(X[i], 3) + b * pow(X[i], 2) + c * X[i] + d;
        cout << endl << "\t\t" << X[i] << "\t|\t" << Y[i];
    }

    float auxx, auxy;
    for (int i = 0; i < n + 3; i++) {
        for (int j = 0; j < n + 3; j++) {
            if (X[j] > X[j + 1]) {
                auxx = X[j];
                auxy = Y[j];
                X[j] = X[j + 1];
                Y[j] = Y[j + 1];
                X[j + 1] = auxx;
                Y[j + 1] = auxy;
            }
        }
    }

    cout << endl << "\t\tLos valores de la tabla (ya ordenada) son:" << endl;
    cout << endl << "\t\tx\t|\ty" << endl << "\t\t===================";
    for (int i = 0; i < n + 4; i++) {
        cout << endl << "\t\t" << X[i] << "\t|\t" << Y[i];
    }

    return 0;
}

